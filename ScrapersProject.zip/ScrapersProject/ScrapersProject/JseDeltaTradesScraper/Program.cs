﻿using System;
using System.Threading.Tasks;
using log4net;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config", Watch = true)]

class Program
{
    static async Task<int> Main(string[] args)
    {
        var logger = LogManager.GetLogger(typeof(Program));
        try
        {
            logger.Info("JSE delta trades scraper started");
            var scraper = new Services.JseScraper(logger);
            var file = await scraper.RunAsync();
            logger.Info($"Saved TSV to: {file}");
            Console.WriteLine($"Done. File: {file}");
            return 0;
        }
        catch (Exception ex)
        {
            logger.Error("Fatal error", ex);
            Console.Error.WriteLine(ex);
            return 1;
        }
    }
}
