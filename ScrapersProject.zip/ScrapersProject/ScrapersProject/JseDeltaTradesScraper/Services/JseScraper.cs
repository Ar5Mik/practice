using System;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Globalization;
using log4net;

namespace Services
{
    public class JseScraper
    {
        private readonly ILog _logger;
        private readonly HttpClient _http;
        private const string Url = "https://clientportal.jse.co.za/reports/delta-option-and-structured-option-trades";

        public JseScraper(ILog logger)
        {
            _logger = logger;
            _http = new HttpClient();
        }

        public async Task<string> RunAsync()
        {
            try
            {
                _logger.Info($"Fetching {Url}");
                var html = await _http.GetStringAsync(Url);
                var doc = new HtmlDocument();
                doc.LoadHtml(html);

                // Попытка найти таблицу
                var table = doc.DocumentNode.SelectSingleNode("//table");
                if (table == null)
                {
                    _logger.Warn("No <table> found on page — likely JS-driven.");
                    var dump = $"jse_raw_{DateTime.UtcNow:yyyyMMdd_HHmmss}.html";
                    System.IO.File.WriteAllText(dump, html);
                    _logger.Info($"Saved raw HTML to {dump}");
                    throw new InvalidOperationException("Table not found in server HTML. The site likely renders table client-side.");
                }

                // Заголовки
                var headers = new List<string>();
                var headerNodes = table.SelectNodes(".//thead//th") ?? table.SelectNodes(".//tr[1]/th");
                if (headerNodes != null)
                {
                    foreach (var h in headerNodes) headers.Add(h.InnerText.Trim());
                }

                // Строки
                var rows = new List<List<string>>();
                var rowNodes = table.SelectNodes(".//tbody//tr") ?? table.SelectNodes(".//tr[position()>1]");
                if (rowNodes != null)
                {
                    foreach (var r in rowNodes)
                    {
                        var cells = r.SelectNodes(".//th|.//td");
                        if (cells == null) continue;
                        var row = new List<string>();
                        foreach (var c in cells) row.Add(HtmlEntity.DeEntitize(c.InnerText).Trim());
                        rows.Add(row);
                    }
                }

                var datePart = DateTime.UtcNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                var fileName = $"jse_delta_trades_{datePart}.tsv";

                CsvWriterHelper.WriteTsv(fileName, headers, rows);
                return fileName;
            }
            catch (Exception ex)
            {
                _logger.Error("Error in JSE scraper", ex);
                throw;
            }
        }
    }
}
