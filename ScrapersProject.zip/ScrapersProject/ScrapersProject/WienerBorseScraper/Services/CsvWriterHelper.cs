using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Services
{
    public static class CsvWriterHelper
    {
       
        public static void WriteTsv(string filePath, List<string> headers, List<List<string>> rows)
        {
            using var sw = new StreamWriter(filePath, false, System.Text.Encoding.UTF8);

            if (headers != null && headers.Count > 0)
            {
                sw.WriteLine(string.Join('\t', headers.Select(h => Escape(h))));
            }

            foreach (var r in rows)
            {
                sw.WriteLine(string.Join('\t', r.Select(c => Escape(c))));
            }
        }

        private static string Escape(string s)
        {
            if (s == null) return string.Empty;
           
            return s.Replace('\t', ' ').Replace("\r", " ").Replace("\n", " ").Trim();
        }
    }
}
