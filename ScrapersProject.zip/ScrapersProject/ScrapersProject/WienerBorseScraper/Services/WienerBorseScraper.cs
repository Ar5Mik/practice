using System;
using System.Net.Http;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Globalization;
using log4net;

namespace Services
{
    public class WienerBorseScraper
    {
        private readonly ILog _logger;
        private readonly HttpClient _http;
        private const string BaseUrl = "https://www.wienerborse.at/en/bonds/";

        public WienerBorseScraper(ILog logger)
        {
            _logger = logger;
            _http = new HttpClient();
        }

        public async Task<string> RunAsync()
        {
            try
            {
                _logger.Info($"Fetching {BaseUrl}");
                var html = await _http.GetStringAsync(BaseUrl);
                var doc = new HtmlDocument();
                doc.LoadHtml(html);

                // Ищем таблицу
                var table = doc.DocumentNode.SelectSingleNode("//table");
                if (table == null)
                {
                    _logger.Warn("No <table> found in page — page might be JS-rendered.");
                    var dumpFile = $"wienerborse_raw_{DateTime.UtcNow:yyyyMMdd_HHmmss}.html";
                    System.IO.File.WriteAllText(dumpFile, html);
                    _logger.Info($"Saved raw HTML to {dumpFile}");
                    throw new InvalidOperationException("Table not found in server HTML. Site likely renders data client-side.");
                }

                // Заголовки
                var headers = new List<string>();
                var headerNodes = table.SelectNodes(".//thead//th") ?? table.SelectNodes(".//tr[1]/th");
                if (headerNodes != null)
                {
                    foreach (var h in headerNodes)
                        headers.Add(h.InnerText.Trim());
                }

                // Строки
                var rows = new List<List<string>>();
                var rowNodes = table.SelectNodes(".//tbody//tr") ?? table.SelectNodes(".//tr[position()>1]");
                if (rowNodes != null)
                {
                    foreach (var r in rowNodes)
                    {
                        var cells = r.SelectNodes(".//th|.//td");
                        var row = new List<string>();
                        if (cells != null)
                        {
                            foreach (var c in cells)
                                row.Add(HtmlEntity.DeEntitize(c.InnerText).Trim());
                            rows.Add(row);
                        }
                    }
                }

                // Имя файла с датой
                var datePart = DateTime.UtcNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                var fileName = $"wienerborse_{datePart}.tsv";

                CsvWriterHelper.WriteTsv(fileName, headers, rows);
                return fileName;
            }
            catch (HttpRequestException hre)
            {
                _logger.Error("Network error while fetching page", hre);
                throw;
            }
            catch (Exception ex)
            {
                _logger.Error("Error in RunAsync", ex);
                throw;
            }
        }
    }
}